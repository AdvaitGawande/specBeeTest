import React from 'react';
import '../App.css';
// import * as HISTORY from '../helpers/history';

class Dashboard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        }
    }

    render() {
        return (
            <div className="app" style={{ backgroundColor: "#E6E6FA" }} >
                <h3>Dashboard Page </h3>
            </div>
        )
    }
}

export default (Dashboard);
