import React from 'react';
import '../App.css';
// import * as HISTORY from '../helpers/history';

class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            email: "",
            password: "",
            enterEmail: false,
            enterPassword: false,
            // invalidUserCred: false
        }
        this.admin = JSON.parse(localStorage.getItem("adminTobe"));
        this.loginUser = this.loginUser.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.registerNewUser = this.registerNewUser.bind(this);
    }

    loginUser(event) {
        console.log("this.admin")
        console.log(this.admin)
        event.preventDefault();
        if (this.state.email === "") {
            this.setState({ enterEmail: true })
        }
        if (this.state.password === "") {
            this.setState({ enterPassword: true })
        }
        if (!this.state.enterEmail && !this.state.enterPassword) {
            if (this.state.email === this.admin.email && this.state.password === this.admin.password) {
                // this.setState({ invalidUserCred: false });
                this.props.history.push("/dashboard");
            } else {
                // this.setState({ invalidUserCred: true });
            }
        }
    }

    handleChange(event) {
        if (event.target.id === "email") {
            this.setState({ email: event.target.value });
            if (event.target.value.trim() !== "") {
                this.setState({ enterEmail: false })
            }
        }
        if (event.target.id === "pass") {
            this.setState({ password: event.target.value });
            if (event.target.value.trim() !== "") {
                this.setState({ enterPassword: false })
            }
        }
    }

    registerNewUser() {
        this.props.history.push("/register")
    }
    render() {
        return (
            <div className="app" style={{ backgroundColor: "#E6E6FA" }} >
                <h3>Login Page</h3>
                <table>
                    <tbody>
                        <tr>
                            <td> <label htmlFor="email"> Email :</label></td>
                            <td><input id="email" type="email" onChange={this.handleChange}></input></td>
                            <td>{this.state.enterEmail && <span>Please Enter Email</span>}</td>
                        </tr>
                        <tr>
                            <td> <label htmlFor="pass"> Password :</label></td>
                            <td> <input id="pass" type="password" onChange={this.handleChange}></input></td>
                            <td>{this.state.enterPassword && <span>Please Enter Password</span>}</td>
                        </tr>
                        <tr>
                            <td><button onClick={this.loginUser}> Login</button></td>
                            <td><button onClick={this.registerNewUser}> New User ? Register</button></td>
                        </tr>
                    </tbody>
                </table>
                {/* {this.state.invalidUserCred && window.alert("Please Enter Valid Cred")} */}
            </div>
        )
    }
}

export default (Login);
