import React from 'react';
import '../App.css';
// import * as HISTORY from '../helpers/history';

class Dashboard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        }
    }

    render() {
        return (
            <div >
                <ul>
                    <li>
                        <a href="/login">Login</a>
                    </li>
                    <li>
                        <a href="/register">Register</a>
                    </li>
                </ul>
            </div>
        )
    }
}

export default (Dashboard);
