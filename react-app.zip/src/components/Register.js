import React from 'react';
import '../App.css';
import * as HISTORY from '../helpers/history'

class Register extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      email: "",
      password: "",
      phoneNumber: "",
      address: "",
      userNameError: false,
      emailError: false,
      passwordError: false,
      phoneNumberError: false,
      addressError: false,

    }
    this.handleFormFields = this.handleFormFields.bind(this)
    this.isUserValid = this.isUserValid.bind(this)
    this.redirectToLogin = this.redirectToLogin.bind(this)
  }

  handleFormFields(event) {
    if (event.target.id === 'name') {
      this.setState({ name: event.target.value });
      if(event.target.value.trim() !== "") {
        this.setState({userNameError: false})
      }
    }
    if (event.target.id === 'email') {
      this.setState({ email: event.target.value })
      if(event.target.value.trim() !== "") {
        this.setState({emailError: false})
      }
    }
    if (event.target.id === 'pass') {
      this.setState({ password: event.target.value })
      if(event.target.value.trim() !== "") {
        this.setState({passwordError: false})
      }
    }
    if (event.target.id === 'cellno') {
      this.setState({ phoneNumber: event.target.value })
      if(event.target.value.trim() !== "") {
        this.setState({phoneNumberError: false})
      }
    }
    if (event.target.id === 'add') {
      this.setState({ address: event.target.value })
      if(event.target.value.trim() !== "") {
        this.setState({addressError: false})
      }
    }
  }

  registerUserDetails(event) {
    event.preventDefault();
    let allValid = this.isUserValid(this.state);
    console.log("allValid")
    console.log(allValid)

    let adminUser = {
      "name": this.state.name,
      "email": this.state.email,
      "password": this.state.password,
      "phoneNumber": this.state.phoneNumber,
      "address": this.state.address,
    }
    if (allValid) {
      localStorage.setItem("adminTobe", JSON.stringify(adminUser));
      window.alert("User Created Click to login page");
      this.props.history.push("/login");
    }
  }

  isUserValid(user) {
    if (user.name === "") {
      this.setState({ userNameError: true });
      return false;
    }
    if (user.email === "") {
      this.setState({ emailError: true });
      return false;
    }
    if (user.password === "") {
      this.setState({ passwordError: true });
      return false;
    }
    if (user.phoneNumber === "") {
      this.setState({ phoneNumberError: true });
      return false;
    }
    if (user.address === "") {
      this.setState({ addressError: true });
      return false;
    } else {
      return true;
    }
  }

  redirectToLogin() {
    this.props.history.push("/login")
  }

  render() {
    return (
      <div className="app" style={{ backgroundColor: "#E6E6FA" }} >
        <h3>
          Bank Registration Form
          </h3>
        <table>
          <tbody>
            <tr>
              <td><label htmlFor="name">Name:</label></td>
              <td><input id="name" type="text" onChange={this.handleFormFields} /></td>
              <td>{this.state.userNameError && <span>Please Add User Name</span>}</td>
            </tr>
            <tr>
              <td><label htmlFor="email">Email Id:</label></td>
              <td><input id="email" type="email" onChange={this.handleFormFields} /></td>
              <td>{this.state.emailError && <span>Please Add Email Id</span>}</td>
            </tr>
            <tr>
              <td><label htmlFor="pass">Password:</label></td>
              <td><input id="pass" type="password" onChange={this.handleFormFields} /></td>
              <td>{this.state.passwordError && <span>Please Add Password</span>}</td>
            </tr>
            <tr>
              <td><label htmlFor="cellno">Phome No:</label></td>
              <td><input id="cellno" type="tel" onChange={this.handleFormFields} /></td>
              <td>{this.state.phoneNumberError && <span>Please Add Phone Number</span>}</td>
            </tr>
            <tr>
              <td><label htmlFor="add">Address:</label></td>
              <td><input id="add" type="Text" onChange={this.handleFormFields} /></td>
              <td>{this.state.addressError && <span>Please Add User Address</span>}</td>
            </tr>
          </tbody>
        </table>
        <button onClick={this.registerUserDetails.bind(this)}>Register User</button>
        <button onClick={this.redirectToLogin.bind(this)}>Already Cutomer ? Login</button>
      </div>
    )
  }
}

export default (Register);
