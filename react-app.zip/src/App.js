import React from 'react';
import { BrowserRouter as Router, Link } from 'react-router-dom';
import Route from 'react-router-dom/Route'
import './App.css';
import Menu from './components/Menu';
import Register from './components/Register';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import *as HISTORY from './helpers/history';

class App extends React.Component {

  render() {
    return (
      <Router history={HISTORY.history}> 
        <div className="App">
          <Route path="/" exact strict component={Menu}/>
          <Route path="/register" exact strict component={Register}/>
          <Route path="/login" exact strict component={Login}/>
          <Route path="/dashboard" exact strict component={Dashboard}/>
        </div>
      </Router>
    )
  }
}

export default (App);
